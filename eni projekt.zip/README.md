# Node.js Backend me SQL Server

CRUD, autentikim dhe testim me Jest.
