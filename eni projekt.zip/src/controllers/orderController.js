
const sql = require('mssql');

const createOrder = async (req, res) => {
  const { productId, quantity } = req.body;
  const userId = req.user.id;

  try {
    const pool = await sql.connect();
    const productResult = await pool.request()
      .input('productId', sql.Int, productId)
      .query('SELECT price FROM Products WHERE id = @productId');

    if (!productResult.recordset[0]) {
      return res.status(404).json({ error: 'Product not found' });
    }

    const price = productResult.recordset[0].price;
    const total = price * quantity;

    await pool.request()
      .input('userId', sql.Int, userId)
      .input('productId', sql.Int, productId)
      .input('quantity', sql.Int, quantity)
      .input('total', sql.Decimal, total)
      .query('INSERT INTO Orders (userId, productId, quantity, total) VALUES (@userId, @productId, @quantity, @total)');

    res.status(201).json({ message: 'Order created successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const getOrdersByUser = async (req, res) => {
  const userId = req.user.id;

  try {
    const pool = await sql.connect();
    const result = await pool.request()
      .input('userId', sql.Int, userId)
      .query('SELECT * FROM Orders WHERE userId = @userId');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const getAllOrders = async (req, res) => {
  try {
    const pool = await sql.connect();
    const result = await pool.request().query('SELECT * FROM Orders');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  createOrder,
  getOrdersByUser,
  getAllOrders
};
