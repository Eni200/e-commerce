
const sql = require('mssql');

const getAllProducts = async (req, res) => {
  try {
    const pool = await sql.connect();
    const result = await pool.request().query('SELECT * FROM Products');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const createProduct = async (req, res) => {
  const { name, description, price, size, stock } = req.body;
  try {
    const pool = await sql.connect();
    await pool.request()
      .input('name', sql.NVarChar, name)
      .input('description', sql.NVarChar, description)
      .input('price', sql.Decimal, price)
      .input('size', sql.NVarChar, size)
      .input('stock', sql.Int, stock)
      .query('INSERT INTO Products (name, description, price, size, stock) VALUES (@name, @description, @price, @size, @stock)');
    res.status(201).json({ message: 'Product created successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const updateProduct = async (req, res) => {
  const { id } = req.params;
  const { name, description, price, size, stock } = req.body;
  try {
    const pool = await sql.connect();
    await pool.request()
      .input('id', sql.Int, id)
      .input('name', sql.NVarChar, name)
      .input('description', sql.NVarChar, description)
      .input('price', sql.Decimal, price)
      .input('size', sql.NVarChar, size)
      .input('stock', sql.Int, stock)
      .query('UPDATE Products SET name=@name, description=@description, price=@price, size=@size, stock=@stock WHERE id=@id');
    res.json({ message: 'Product updated successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const deleteProduct = async (req, res) => {
  const { id } = req.params;
  try {
    const pool = await sql.connect();
    await pool.request()
      .input('id', sql.Int, id)
      .query('DELETE FROM Products WHERE id=@id');
    res.json({ message: 'Product deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  getAllProducts,
  createProduct,
  updateProduct,
  deleteProduct
};
