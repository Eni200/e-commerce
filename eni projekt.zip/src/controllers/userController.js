const sql = require('mssql');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
    const { name, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const pool = await sql.connect();
    await pool.request()
        .input('name', sql.NVarChar, name)
        .input('email', sql.NVarChar, email)
        .input('password', sql.NVarChar, hashedPassword)
        .query('INSERT INTO Users (name, email, password) VALUES (@name, @email, @password)');
    res.status(201).json({ message: 'User created' });
};

exports.login = async (req, res) => {
    // Implementimi i login
};

exports.profile = async (req, res) => {
    res.json({ user: req.user });
};
