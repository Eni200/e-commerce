
CREATE TABLE Orders (
  id INT PRIMARY KEY IDENTITY(1,1),
  userId INT NOT NULL,
  productId INT NOT NULL,
  quantity INT NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  createdAt DATETIME DEFAULT GETDATE(),
  FOREIGN KEY (userId) REFERENCES Users(id),
  FOREIGN KEY (productId) REFERENCES Products(id)
);
